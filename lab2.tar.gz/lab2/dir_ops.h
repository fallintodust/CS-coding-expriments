#ifndef DIR_OPS_H
#define DIR_OPS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>

/**
 * @brief 获取目录下的文件列表
 * @param dirname 目录路径
 * @param show_details 是否显示详细信息（时间、大小等）
 * @return 成功返回0，失败返回-1
 */
int list_directory(const char *dirname, int show_details);

/**
 * @brief 将目录打包为tar.gz文件
 * @param dirname 要打包的目录路径
 * @param packname 输出的包文件名
 * @return 成功返回0，失败返回-1
 */
int pack_directory(const char *dirname, const char *packname);

/**
 * @brief 解包tar.gz文件到指定目录
 * @param packname 包文件路径
 * @param target_dir 解包目标目录
 * @return 成功返回0，失败返回-1
 */
int unpack_directory(const char *packname, const char *target_dir);

#endif // DIR_OPS_H
