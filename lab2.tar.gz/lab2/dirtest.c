#include "dirops.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <command> [args...]\n", argv[0]);
        printf("Commands:\n");
        printf("  list <dirname>           - List directory contents\n");
        printf("  pack <dirname> <outfile> - Pack directory into file\n");
        printf("  unpack <file> <outdir>   - Unpack file into directory\n");
        return 1;
    }

    if (strcmp(argv[1], "list") == 0 && argc == 3) {
        return list_directory(argv[2]);
    }
    else if (strcmp(argv[1], "pack") == 0 && argc == 4) {
        return pack_directory(argv[2], argv[3]);
    }
    else if (strcmp(argv[1], "unpack") == 0 && argc == 4) {
        return unpack_directory(argv[2], argv[3]);
    }
    else {
        printf("Invalid command or arguments\n");
        return 1;
    }
}
