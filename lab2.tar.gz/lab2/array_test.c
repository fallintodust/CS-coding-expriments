#include "fileop.h"
#include <time.h>
#include <sys/stat.h>

#define ARRAY_SIZE 100

int main() {
    // 1. 初始化测试数据
    float float_array[ARRAY_SIZE];
    char char_array[ARRAY_SIZE];
    
    srand(time(NULL));
    for(int i = 0; i < ARRAY_SIZE; i++) {
        float_array[i] = (float)rand() / RAND_MAX * 100.0;
        char_array[i] = 'A' + (i % 26);
    }
    
    // 2. 写入文件
    printf("\n=== 写入测试 ===\n");
    
    // 二进制文件写入
    write_float_array_binary("float.bin", float_array, ARRAY_SIZE);
    write_char_array_binary("char.bin", char_array, ARRAY_SIZE);
    
    // 文本文件写入
    FILE *fp_float = fopen("float.txt", "w");
    FILE *fp_char = fopen("char.txt", "w");
    for(int i = 0; i < ARRAY_SIZE; i++) {
        fprintf(fp_float, "%.6f\n", float_array[i]);
        fprintf(fp_char, "%c\n", char_array[i]);
    }
    fclose(fp_float);
    fclose(fp_char);
    
    // 3. 读取测试
    printf("\n=== 读取测试 ===\n");
    float float_read[ARRAY_SIZE];
    read_float_array_binary("float.bin", float_read, ARRAY_SIZE);
    
    // 4. 验证并显示部分数据
    printf("\n=== 数据验证 ===\n");
    printf("原始数据(前5个):\t");
    for(int i = 0; i < 5; i++) printf("%.2f ", float_array[i]);
    printf("\n读取数据(前5个):\t");
    for(int i = 0; i < 5; i++) printf("%.2f ", float_read[i]);
    printf("\n");
    
    // 5. 显示文件大小
    printf("\n=== 文件大小比较 ===\n");
    struct stat st;
    stat("float.bin", &st);
    printf("float.bin: %ld 字节\n", st.st_size);
    stat("char.bin", &st);
    printf("char.bin: %ld 字节\n", st.st_size);
    stat("float.txt", &st);
    printf("float.txt: %ld 字节\n", st.st_size);
    stat("char.txt", &st);
    printf("char.txt: %ld 字节\n", st.st_size);
    
    return 0;
}
