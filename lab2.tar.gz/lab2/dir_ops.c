#include "dir_ops.h"

// 用于格式化文件大小显示
static char* format_size(off_t size) {
    static char buf[32];
    const char* units[] = {"B", "KB", "MB", "GB"};
    int i = 0;
    double dsize = size;
    
    while (dsize >= 1024 && i < 3) {
        dsize /= 1024;
        i++;
    }
    
    sprintf(buf, "%.1f %s", dsize, units[i]);
    return buf;
}

int list_directory(const char *dirname, int show_details) {
    if (!dirname) {
        fprintf(stderr, "Error: Directory name is NULL\n");
        return -1;
    }

    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char filepath[1024];
    
    // 打开目录
    dir = opendir(dirname);
    if (dir == NULL) {
        fprintf(stderr, "Error: Cannot open directory '%s': %s\n", 
                dirname, strerror(errno));
        return -1;
    }
    
    // 打印表头
    printf("\n=== Directory listing for: %s ===\n", dirname);
    if (show_details) {
        printf("%-30s %-10s %-15s %-20s\n", 
               "Name", "Type", "Size", "Modified Time");
        printf("------------------------------------------------------------\n");
    } else {
        printf("%-30s %-10s\n", "Name", "Type");
        printf("----------------------------------------\n");
    }
    
    // 读取目录内容
    while ((entry = readdir(dir)) != NULL) {
        // 跳过 "." 和 ".."
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;
            
        // 构建完整文件路径
        snprintf(filepath, sizeof(filepath), "%s/%s", dirname, entry->d_name);
        
        // 获取文件信息
        if (stat(filepath, &file_stat) == -1) {
            fprintf(stderr, "Warning: Cannot get stats for '%s'\n", filepath);
            continue;
        }
        
        // 确定文件类型
        const char *type = "unknown";
        if (S_ISREG(file_stat.st_mode))
            type = "file";
        else if (S_ISDIR(file_stat.st_mode))
            type = "dir";
        else if (S_ISLNK(file_stat.st_mode))
            type = "link";
            
        // 打印文件信息
        if (show_details) {
            char time_str[20];
            strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M", 
                    localtime(&file_stat.st_mtime));
            printf("%-30s %-10s %-15s %-20s\n",
                   entry->d_name,
                   type,
                   format_size(file_stat.st_size),
                   time_str);
        } else {
            printf("%-30s %-10s\n", entry->d_name, type);
        }
    }
    
    printf("----------------------------------------\n");
    closedir(dir);
    return 0;
}

int pack_directory(const char *dirname, const char *packname) {
    if (!dirname || !packname) {
        fprintf(stderr, "Error: Invalid parameters\n");
        return -1;
    }
    char command[1024];
    
    // 检查目录是否存在
    DIR *dir = opendir(dirname);
    if (dir == NULL) {
        fprintf(stderr, "Error: Directory '%s' does not exist\n", dirname);
        return -1;
    }
    closedir(dir);
    
    // 构建tar命令
    printf("Packing directory '%s' into '%s'...\n", dirname, packname);
    if (snprintf(command, sizeof(command), 
             "tar -czf %s %s 2>/dev/null", packname, dirname) >= sizeof(command)) {
        fprintf(stderr, "Error: Command too long\n");
        return -1;
    }
    
    // 执行打包命令
    int result = system(command);
    if (result != 0) {
        fprintf(stderr, "Error: Failed to create package\n");
        return -1;
    }
    
    // 验证打包文件是否创建成功
    struct stat st;
    if (stat(packname, &st) == 0) {
        printf("Successfully created package: %s (size: %s)\n", 
               packname, format_size(st.st_size));
        return 0;
    } else {
        fprintf(stderr, "Error: Package file was not created\n");
        return -1;
    }
}

int unpack_directory(const char *packname, const char *target_dir) {
    char command[1024];
    
    // 检查包文件是否存在
    struct stat st;
    if (stat(packname, &st) != 0) {
        fprintf(stderr, "Error: Package file '%s' does not exist\n", packname);
        return -1;
    }
    
    // 创建目标目录（如果不存在）
    if (mkdir(target_dir, 0755) != 0 && errno != EEXIST) {
        fprintf(stderr, "Error: Cannot create target directory: %s\n", 
                strerror(errno));
        return -1;
    }
    
    // 构建解包命令
    printf("Unpacking '%s' into directory '%s'...\n", packname, target_dir);
    snprintf(command, sizeof(command), 
             "cd %s && tar -xzf ../%s", target_dir, packname);
    
    // 执行解包命令
    int result = system(command);
    if (result != 0) {
        fprintf(stderr, "Error: Failed to unpack\n");
        return -1;
    }
    
    printf("Successfully unpacked into: %s\n", target_dir);
    return 0;
}
