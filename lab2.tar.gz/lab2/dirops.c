#include "dirops.h"

// 获取目录下的文件列表
int list_directory(const char *dirname) {
    DIR *dir;
    struct dirent *entry;
    struct stat file_stat;
    char filepath[1024];
    
    // 打开目录
    dir = opendir(dirname);
    if (dir == NULL) {
        fprintf(stderr, "Error: Cannot open directory '%s': %s\n", 
                dirname, strerror(errno));
        return -1;
    }
    
    printf("\n=== Directory listing for: %s ===\n", dirname);
    printf("%-40s %-10s %-10s\n", "Name", "Type", "Size(bytes)");
    printf("------------------------------------------------\n");
    
    // 读取目录项
    while ((entry = readdir(dir)) != NULL) {
        // 跳过 "." 和 ".."
        if (strcmp(entry->d_name, ".") == 0 || 
            strcmp(entry->d_name, "..") == 0)
            continue;
            
        // 构建完整文件路径
        snprintf(filepath, sizeof(filepath), "%s/%s", dirname, entry->d_name);
        
        // 获取文件信息
        if (stat(filepath, &file_stat) == -1) {
            fprintf(stderr, "Error: Cannot get stats for '%s': %s\n", 
                    filepath, strerror(errno));
            continue;
        }
        
        // 确定文件类型
        const char *type = "unknown";
        if (S_ISREG(file_stat.st_mode))
            type = "file";
        else if (S_ISDIR(file_stat.st_mode))
            type = "dir";
        else if (S_ISLNK(file_stat.st_mode))
            type = "link";
            
        // 打印文件信息
        printf("%-40s %-10s %-10ld\n", 
               entry->d_name, 
               type, 
               file_stat.st_size);
    }
    
    printf("------------------------------------------------\n");
    closedir(dir);
    return 0;
}

// 打包目录
int pack_directory(const char *dirname, const char *packname) {
    char command[1024];
    printf("Packing directory '%s' into '%s'...\n", dirname, packname);
    
    // 使用tar命令打包目录
    snprintf(command, sizeof(command), 
             "tar -czf %s %s 2>/dev/null", packname, dirname);
    
    int result = system(command);
    if (result == 0) {
        printf("Successfully created package: %s\n", packname);
        return 0;
    } else {
        fprintf(stderr, "Error: Failed to create package\n");
        return -1;
    }
}

// 解包文件
int unpack_directory(const char *packname, const char *dirname) {
    char command[1024];
    
    // 创建目标目录（如果不存在）
    mkdir(dirname, 0755);
    
    printf("Unpacking '%s' into directory '%s'...\n", packname, dirname);
    
    // 使用tar命令解包
    snprintf(command, sizeof(command), 
             "cd %s && tar -xzf ../%s 2>/dev/null", dirname, packname);
    
    int result = system(command);
    if (result == 0) {
        printf("Successfully unpacked into: %s\n", dirname);
        return 0;
    } else {
        fprintf(stderr, "Error: Failed to unpack\n");
        return -1;
    }
}
