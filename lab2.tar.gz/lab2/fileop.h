#ifndef FILEOP_H
#define FILEOP_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

// 结构体定义
struct myrecord {
    unsigned long id;        // 编号 8
    char name[32];          // 姓名 32
    float score[3];         // 3个分数 4*3=12
    int weight;             // 体重 4
};

/**
 * 从文本文件读取记录数据
 * @param filename: 输入文件名
 * @param records: 存储记录的数组指针
 * @param max_records: 最大记录数
 * @return: 实际读取的记录数，失败返回-1
 */
int read_text_file(const char *filename, struct myrecord **records, int max_records);

/**
 * 将记录写入二进制文件
 * @param filename: 输出文件名
 * @param records: 记录数组
 * @param count: 记录数量
 * @return: 成功返回0，失败返回-1
 */
int write_binary_file(const char *filename, struct myrecord *records, int count);

/**
 * 从二进制文件读取记录数据
 * @param filename: 输入文件名
 * @param records: 存储记录的数组指针
 * @param max_records: 最大记录数
 * @return: 实际读取的记录数，失败返回-1
 */
int read_binary_file(const char *filename, struct myrecord **records, int max_records);

/**
 * 将记录写入文本文件
 * @param filename: 输出文件名
 * @param records: 记录数组
 * @param count: 记录数量
 * @return: 成功返回0，失败返回-1
 */
int write_text_file(const char *filename, struct myrecord *records, int count);

/**
 * 打印记录到屏幕
 * @param records: 记录数组
 * @param count: 记录数量
 */
void print_records(struct myrecord *records, int count);

/**
 * 写入浮点数组到二进制文件
 * @param filename: 文件名
 * @param array: 浮点数组
 * @param size: 数组大小
 * @return: 成功返回0，失败返回-1
 */
int write_float_array_binary(const char *filename, float *array, int size);

/**
 * 从二进制文件读取浮点数组
 * @param filename: 文件名
 * @param array: 存储数组
 * @param size: 数组大小
 * @return: 成功返回0，失败返回-1
 */
int read_float_array_binary(const char *filename, float *array, int size);

/**
 * 写入字符数组到二进制文件
 * @param filename: 文件名
 * @param array: 字符数组
 * @param size: 数组大小
 * @return: 成功返回0，失败返回-1
 */
int write_char_array_binary(const char *filename, char *array, int size);

/**
 * 从二进制文件读取字符数组
 * @param filename: 文件名
 * @param array: 存储数组
 * @param size: 数组大小
 * @return: 成功返回0，失败返回-1
 */
int read_char_array_binary(const char *filename, char *array, int size);

/**
 * 错误处理函数
 * @param message: 错误信息
 */
void print_error(const char *message);

#endif // FILEOP_H