#include "fileop.h"
#include <math.h>

// 错误处理函数
void print_error(const char *message) {
    printf("Error: %s\n", message);
    if (errno != 0) {
        printf("System error %d: %s\n", errno, strerror(errno));
    }
}

// 从文本文件读取记录数据
int read_text_file(const char *filename, struct myrecord **records, int max_records) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        print_error("Cannot open text file for reading");
        return -1;
    }
    
    // 动态分配内存存储记录
    *records = (struct myrecord *)malloc(max_records * sizeof(struct myrecord));
    if (*records == NULL) {
        print_error("Memory allocation failed");
        fclose(file);
        return -1;
    }
    
    char line[256];
    int count = 0;
    int line_count = 0;
    int empty_file = 1;
    printf("Reading from text file: %s\n", filename);
    while (fgets(line, sizeof(line), file) != NULL) {
        line_count++;
        empty_file = 0;
        // 检查全角和半角空格，并自动替换全角空格为半角空格
        int has_fullwidth = 0, has_halfwidth = 0;
        char newline[256];
        int j = 0;
        for (int i = 0; line[i] != '\0' && j < 255; ) {
            // 检查半角空格
            if (line[i] == ' ') {
                has_halfwidth = 1;
                newline[j++] = line[i++];
            }
            // 检查全角空格（UTF-8编码0xE3 0x80 0x80），替换为半角空格
            else if ((unsigned char)line[i] == 0xE3 && (unsigned char)line[i+1] == 0x80 && (unsigned char)line[i+2] == 0x80) {
                has_fullwidth = 1;
                newline[j++] = ' ';
                i += 3;
            } else {
                newline[j++] = line[i++];
            }
        }
        newline[j] = '\0';
        if (has_fullwidth) printf("Warning: Line %d contains fullwidth space, replaced with halfwidth.\n", line_count);
        if (has_halfwidth) printf("Warning: Line %d contains halfwidth space.\n", line_count);
        if (count < max_records) {
            int parsed = sscanf(newline, "%lu %31s %f %f %f %d",
                               &(*records)[count].id,
                               (*records)[count].name,
                               &(*records)[count].score[0],
                               &(*records)[count].score[1],
                               &(*records)[count].score[2],
                               &(*records)[count].weight);
            if (parsed == 6) {
                count++;
                printf("Parsed record %d: ID=%lu, Name=%s\n", count, (*records)[count-1].id, (*records)[count-1].name);
            } else {
                printf("Warning: Failed to parse line: %s", newline);
            }
        }
    }
    fclose(file);
    if (empty_file) {
        printf("Warning: File is empty!\n");
    }
    printf("Total lines in file: %d\n", line_count);
    if (line_count == 3) {
        printf("Warning: File only has 3 lines!\n");
    }
    printf("Successfully read %d records from text file\n", count);
    return count;
}

// 将记录写入二进制文件
int write_binary_file(const char *filename, struct myrecord *records, int count) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        print_error("Cannot open binary file for writing");
        return -1;
    }
    
    // 先写入记录数量
    size_t written_count = fwrite(&count, sizeof(int), 1, file);
    if (written_count != 1) {
        print_error("Failed to write record count to binary file");
        fclose(file);
        return -1;
    }
    
    // 写入所有记录
    written_count = fwrite(records, sizeof(struct myrecord), count, file);
    if ((int)written_count != count) {
        print_error("Failed to write all records to binary file");
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully wrote %d records to binary file: %s\n", count, filename);
    return 0;
}

// 从二进制文件读取记录数据
int read_binary_file(const char *filename, struct myrecord **records, int max_records) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        print_error("Cannot open binary file for reading");
        return -1;
    }
    
    // 读取记录数量
    int count;
    size_t read_count = fread(&count, sizeof(int), 1, file);
    if (read_count != 1) {
        print_error("Failed to read record count from binary file");
        fclose(file);
        return -1;
    }
    
    if (count > max_records) {
        printf("Warning: File contains %d records, but max_records is %d\n", count, max_records);
        count = max_records;
    }
    
    // 动态分配内存
    *records = (struct myrecord *)malloc(count * sizeof(struct myrecord));
    if (*records == NULL) {
        print_error("Memory allocation failed");
        fclose(file);
        return -1;
    }
    
    // 读取所有记录
    read_count = fread(*records, sizeof(struct myrecord), count, file);
    if ((int)read_count != count) {
        print_error("Failed to read all records from binary file");
        free(*records);
        *records = NULL;
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully read %d records from binary file: %s\n", count, filename);
    return count;
}

// 将记录写入文本文件
int write_text_file(const char *filename, struct myrecord *records, int count) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        print_error("Cannot open text file for writing");
        return -1;
    }
    
    for (int i = 0; i < count; i++) {
        int error = 0;
        char status[128] = "";
        for (int j = 0; j < 3; j++) {
            if (!isfinite(records[i].score[j])) {
                strcat(status, "Score");
                char idx[2]; sprintf(idx, "%d", j+1);
                strcat(status, idx);
                strcat(status, " NaN; ");
                error = 1;
            } else if (records[i].score[j] < 0) {
                strcat(status, "Score");
                char idx[2]; sprintf(idx, "%d", j+1);
                strcat(status, idx);
                strcat(status, " <0; ");
                error = 1;
            }
        }
        if (records[i].weight < 30 || records[i].weight > 90) {
            strcat(status, "Weight out of range; ");
            error = 1;
        }
        if (!error) strcpy(status, "OK");
        fprintf(file, "%lu\t%s\t%.2f\t%.2f\t%.2f\t%d\t%s\n",
                records[i].id,
                records[i].name,
                records[i].score[0],
                records[i].score[1],
                records[i].score[2],
                records[i].weight,
                status);
    }
    
    fclose(file);
    printf("Successfully wrote %d records to text file: %s\n", count, filename);
    return 0;
}

// 打印记录到屏幕
void print_records(struct myrecord *records, int count) {
    printf("\n=== Records Display ===\n");
    printf("ID\t\tName\t\tScore1\tScore2\tScore3\tWeight\n");
    printf("----------------------------------------------------------------\n");
    
    for (int i = 0; i < count; i++) {
            int error = 0;
            char status[128] = "";
            for (int j = 0; j < 3; j++) {
                if (!isfinite(records[i].score[j])) {
                    strcat(status, "Score");
                    char idx[2]; sprintf(idx, "%d", j+1);
                    strcat(status, idx);
                    strcat(status, " NaN; ");
                    error = 1;
                } else if (records[i].score[j] < 0) {
                    strcat(status, "Score");
                    char idx[2]; sprintf(idx, "%d", j+1);
                    strcat(status, idx);
                    strcat(status, " <0; ");
                    error = 1;
                }
            }
            if (records[i].weight < 30 || records[i].weight > 90) {
                strcat(status, "Weight out of range; ");
                error = 1;
            }
            if (!error) strcpy(status, "OK");
            printf("%lu\t%-15s\t%.2f\t%.2f\t%.2f\t%d\t%s\n",
                   records[i].id,
                   records[i].name,
                   records[i].score[0],
                   records[i].score[1],
                   records[i].score[2],
                   records[i].weight,
                   status);
    }
    printf("================================================================\n\n");
}

// 写入浮点数组到二进制文件
int write_float_array_binary(const char *filename, float *array, int size) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        print_error("Cannot open file for writing float array");
        return -1;
    }
    
    size_t written = fwrite(array, sizeof(float), size, file);
    if ((int)written != size) {
        print_error("Failed to write complete float array");
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully wrote %d floats to binary file: %s\n", size, filename);
    return 0;
}

// 从二进制文件读取浮点数组
int read_float_array_binary(const char *filename, float *array, int size) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        print_error("Cannot open file for reading float array");
        return -1;
    }
    
    size_t read_count = fread(array, sizeof(float), size, file);
    if ((int)read_count != size) {
        print_error("Failed to read complete float array");
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully read %d floats from binary file: %s\n", size, filename);
    return 0;
}

// 写入字符数组到二进制文件
int write_char_array_binary(const char *filename, char *array, int size) {
    FILE *file = fopen(filename, "wb");
    if (file == NULL) {
        print_error("Cannot open file for writing char array");
        return -1;
    }
    
    size_t written = fwrite(array, sizeof(char), size, file);
    if ((int)written != size) {
        print_error("Failed to write complete char array");
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully wrote %d chars to binary file: %s\n", size, filename);
    return 0;
}

// 从二进制文件读取字符数组
int read_char_array_binary(const char *filename, char *array, int size) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        print_error("Cannot open file for reading char array");
        return -1;
    }
    
    size_t read_count = fread(array, sizeof(char), size, file);
    if ((int)read_count != size) {
        print_error("Failed to read complete char array");
        fclose(file);
        return -1;
    }
    
    fclose(file);
    printf("Successfully read %d chars from binary file: %s\n", size, filename);
    return 0;
}