#include "fileop.h"

int main() {
    struct myrecord *records;
    int count;

    // 1. 从文本文件读取数据
    printf("\n=== 从文本文件读取数据 ===\n");
    count = read_text_file("input.txt", &records, 100);
    if (count <= 0) {
        printf("读取文本文件失败\n");
        return 1;
    }
    printf("从文本文件读取了 %d 条记录\n", count);

    // 2. 写入二进制文件
    printf("\n=== 写入二进制文件 ===\n");
    if (write_binary_file("records.bin", records, count) != 0) {
        printf("写入二进制文件失败\n");
        free(records);
        return 1;
    }
    free(records);

    // 3. 从二进制文件读取
    printf("\n=== 从二进制文件读取 ===\n");
    struct myrecord *read_records;
    int read_count = read_binary_file("records.bin", &read_records, 100);
    
    if (read_count > 0) {
        printf("\n读取的记录：\n");
        for (int i = 0; i < read_count; i++) {
            printf("ID: %lu, Name: %s, Scores: %.1f, %.1f, %.1f, Weight: %d\n",
                   read_records[i].id,
                   read_records[i].name,
                   read_records[i].score[0],
                   read_records[i].score[1],
                   read_records[i].score[2],
                   read_records[i].weight);
        }
        free(read_records);
    }

    return 0;
}
