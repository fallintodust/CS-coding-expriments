#include "fileop.h"

#define MAX_RECORDS 1000

void print_usage(const char *program_name) {
    printf("Usage:\n");
    printf("  Function 1 (Text to Binary):\n");
    printf("    %s 1 <input_text_file> <output_binary_file>\n", program_name);
    printf("    Example: %s 1 ./testfile.txt ./binfile.dat\n\n", program_name);
    
    printf("  Function 2 (Binary to Text):\n");
    printf("    %s 2 <input_binary_file> <output_text_file>\n", program_name);
    printf("    Example: %s 2 ./binfile.dat ./testfile2.txt\n\n", program_name);
    
    printf("  Additional Functions:\n");
    printf("  Function 3 (Demo basic binary operations):\n");
    printf("    %s 3\n", program_name);
}

// 功能1：从文本文件读数据，写入二进制文件
int function1(const char *input_file, const char *output_file) {
    printf("\n=== Function 1: Text File to Binary File ===\n");
    
    struct myrecord *records = NULL;
    int count = read_text_file(input_file, &records, MAX_RECORDS);
    
    if (count <= 0) {
        printf("Failed to read records from text file\n");
        return -1;
    }
    
    // 格式化输出到屏幕
    print_records(records, count);
    
    // 写入二进制文件
    int result = write_binary_file(output_file, records, count);
    
    // 清理内存
    free(records);
    
    return result;
}

// 功能2：从二进制文件读数据，写入文本文件
int function2(const char *input_file, const char *output_file) {
    printf("\n=== Function 2: Binary File to Text File ===\n");
    
    struct myrecord *records = NULL;
    int count = read_binary_file(input_file, &records, MAX_RECORDS);
    
    if (count <= 0) {
        printf("Failed to read records from binary file\n");
        return -1;
    }
    
    // 格式化输出到屏幕
    print_records(records, count);
    
    // 写入文本文件
    int result = write_text_file(output_file, records, count);
    
    // 清理内存
    free(records);
    
    return result;
}

// 功能3：演示基本的二进制文件操作
int function3() {
    printf("\n=== Function 3: Demo Basic Binary Operations ===\n");
    
    // 创建测试数据
    float float_array[100];
    char char_array[100];
    
    // 初始化浮点数组
    for (int i = 0; i < 100; i++) {
        float_array[i] = i * 3.14f + 1.5f;
    }
    
    // 初始化字符数组
    for (int i = 0; i < 100; i++) {
        char_array[i] = 'A' + (i % 26);
    }
    
    // 写入浮点数组到二进制文件
    if (write_float_array_binary("float_array.dat", float_array, 100) != 0) {
        return -1;
    }
    
    // 写入字符数组到二进制文件
    if (write_char_array_binary("char_array.dat", char_array, 100) != 0) {
        return -1;
    }
    
    // 读取并验证数据
    float read_floats[100];
    char read_chars[100];
    
    if (read_float_array_binary("float_array.dat", read_floats, 100) != 0) {
        return -1;
    }
    
    if (read_char_array_binary("char_array.dat", read_chars, 100) != 0) {
        return -1;
    }
    
    // 验证数据完整性
    printf("\nVerifying data integrity...\n");
    int float_errors = 0, char_errors = 0;
    
    for (int i = 0; i < 100; i++) {
        if (float_array[i] != read_floats[i]) {
            float_errors++;
        }
        if (char_array[i] != read_chars[i]) {
            char_errors++;
        }
    }
    
    printf("Float array verification: %s (%d errors)\n", 
           float_errors == 0 ? "PASSED" : "FAILED", float_errors);
    printf("Char array verification: %s (%d errors)\n", 
           char_errors == 0 ? "PASSED" : "FAILED", char_errors);
    
    // 显示部分数据
    printf("\nSample float data (first 10):\n");
    for (int i = 0; i < 10; i++) {
        printf("%.2f ", read_floats[i]);
    }
    printf("\n\nSample char data (first 30):\n");
    for (int i = 0; i < 30; i++) {
        printf("%c", read_chars[i]);
    }
    printf("\n\n");
    
    return 0;
}

// 创建测试用的文本文件
void create_test_file() {
    FILE *file = fopen("testfile.txt", "w");
    if (file == NULL) {
        print_error("Cannot create test file");
        return;
    }
    
    fprintf(file, "1007 wangsan    97.5    90.0  88.9  70\n");
    fprintf(file, "1008 zhaosan    98.5    80.0  89.9  91\n");
    fprintf(file, "1009 lisan    99.5    79.0  99.9  72\n");
    fprintf(file, "1010 liusan    95.5    100.0 59.9 83\n");
    
    fclose(file);
    printf("Created test file: testfile.txt\n");
}

int main(int argc, char *argv[]) {
    printf("File Operations Program\n");
    printf("=======================\n");
    
    // 检查命令行参数
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }
    
    int function_code = atoi(argv[1]);
    
    switch (function_code) {
        case 1:
            if (argc != 4) {
                printf("Error: Function 1 requires 3 arguments\n");
                print_usage(argv[0]);
                return 1;
            }
            return function1(argv[2], argv[3]);
            
        case 2:
            if (argc != 4) {
                printf("Error: Function 2 requires 3 arguments\n");
                print_usage(argv[0]);
                return 1;
            }
            return function2(argv[2], argv[3]);
            
        case 3:
            return function3();
            
        case 0:
            // 创建测试文件的隐藏功能
            create_test_file();
            return 0;
            
        default:
            printf("Error: Invalid function code %d\n", function_code);
            print_usage(argv[0]);
            return 1;
    }
    
    return 0;
}