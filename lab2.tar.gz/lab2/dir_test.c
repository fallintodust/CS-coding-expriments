#include "dir_ops.h"

void print_usage(const char* program) {
    printf("Usage: %s <command> [args...]\n", program);
    printf("Commands:\n");
    printf("  list <dirname> [detail]    - List directory contents\n");
    printf("  pack <dirname> <outfile>   - Pack directory into file\n");
    printf("  unpack <file> <outdir>    - Unpack file into directory\n");
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        print_usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "list") == 0) {
        return list_directory(argv[2], argc > 3);
    }
    else if (strcmp(argv[1], "pack") == 0 && argc == 4) {
        return pack_directory(argv[2], argv[3]);
    }
    else if (strcmp(argv[1], "unpack") == 0 && argc == 4) {
        return unpack_directory(argv[2], argv[3]);
    }
    else {
        print_usage(argv[0]);
        return 1;
    }
}
