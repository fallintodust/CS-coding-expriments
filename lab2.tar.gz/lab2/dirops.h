#ifndef DIROPS_H
#define DIROPS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>

// 获取目录下的文件列表
int list_directory(const char *dirname);

// 打包目录
int pack_directory(const char *dirname, const char *packname);

// 解包文件
int unpack_directory(const char *packname, const char *dirname);

#endif // DIROPS_H
